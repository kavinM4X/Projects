import React from "react"
import Quiz from "./Components/Quizz/Quiz"

const App = () => {
  return ( 
    <>
     <Quiz/>
    </>
    )
}

export default App